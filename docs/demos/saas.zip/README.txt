Syntyr source candidate 0.3.0-alpha.5
Open index.html locally; keep CSS and assets alongside it.
This is a presentation scaffold, not a working application.
Sample copy, routes, forms and data need review before deployment.
See validation.json for coverage, limitations and host obligations.
Regenerate from the matching source checkout: python3 scripts/generate_ui.py < request.json
Import project.json in the matching visual builder to edit.
